package controller.exeption;

public class UsernameNotFound extends Exception{
public UsernameNotFound(){super("Username and password didn’t match!");}
}
