package controller.exeption;

public class CanNotSet extends Exception{
public CanNotSet(){super("you can’t set this card");}
}
