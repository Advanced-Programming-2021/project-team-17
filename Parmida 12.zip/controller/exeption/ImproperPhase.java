package controller.exeption;

public class ImproperPhase extends Exception{
public ImproperPhase(){super("action not allowed in this phase");}
}
