package controller.exeption;

public class WrongMenuNavigation extends Exception{
public WrongMenuNavigation(){super("menu navigation is not possible");}
}
