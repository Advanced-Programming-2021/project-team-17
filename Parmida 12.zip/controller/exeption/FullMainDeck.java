package controller.exeption;

public class FullMainDeck extends Exception{
public FullMainDeck(){super("main deck is full");}
}
