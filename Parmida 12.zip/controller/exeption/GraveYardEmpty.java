package controller.exeption;

public class GraveYardEmpty extends Exception{
public GraveYardEmpty(){super("graveyard empty");}
}
