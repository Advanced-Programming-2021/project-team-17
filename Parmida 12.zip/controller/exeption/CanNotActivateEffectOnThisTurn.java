package controller.exeption;

public class CanNotActivateEffectOnThisTurn extends Exception{
public CanNotActivateEffectOnThisTurn(){super("you can’t activate an effect on this turn");}
}
