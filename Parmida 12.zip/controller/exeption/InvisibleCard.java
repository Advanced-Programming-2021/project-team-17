package controller.exeption;

public class InvisibleCard extends Exception{
    //TODO nemidunam chie
}
