package controller.exeption;

public class InvalidCommand extends Exception{
    public InvalidCommand(){super("invalid command");}
}
