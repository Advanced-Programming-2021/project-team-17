package controller.exeption;

public class CanNotSpecialSummon extends Exception{
public CanNotSpecialSummon(){super("there is no way you could special summon a monster");}
}
