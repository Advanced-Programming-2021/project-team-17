package controller.exeption;

public class UnsupportedRoundNumber extends Exception{
public UnsupportedRoundNumber(){super("number of rounds is not supported");}
}
