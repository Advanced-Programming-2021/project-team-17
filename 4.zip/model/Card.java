package model;
public interface Card {
    public String getName();
    public String getNamePascalCase();
    public String getDescription();

}
