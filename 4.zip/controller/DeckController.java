package controller;

import model.*;
import view.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//TODO exeptiona
public class DeckController {
    private static DeckController instance = null;
    private User user;

    private DeckController(User user) {
        this.user = user;
    }

    public static DeckController getInstance(User user) {
        if (instance == null) instance = new DeckController(user);
        else instance.user = user;
        return instance;
    }

    private void createDeck(String name) {
        Deck deck = new Deck(name);
        this.user.addDeck(deck);
    }

    private void deleteDeck(String name) {
        this.user.deleteDeck(name);
    }

    private void activateDeck(String name) {
        user.setActiveDeck(user.getDeckByName(name));
    }

    private void addCardToDeck(String cardName, String deckName, boolean isSide) {
        Deck deck = user.getDeckByName(deckName);
        Card card = user.getCardByName(cardName);
        if (isSide) deck.addCardToSideDeck(card);
        else deck.addCardToMainDeck(card);
    }

    private void removeCardFromDeck(String cardName, String deckName, boolean isSide) {
        Deck deck = user.getDeckByName(deckName);
        Card card = user.getCardByName(cardName);
        if (isSide) deck.removeCardFromSideDeck(card);
        else deck.removeCardFromMainDeck(card);
    }

    private void showAllDecks() {
        String toPrint = "Decks:\nActive deck:\n";
        List<Deck> allDecks = this.user.getAllDecks();
        Deck activeDeck = null;
        for (Deck deck : allDecks) {
            if (deck.equals(user.getActiveDeck())) {
                toPrint += deck.getDeckName() + ": main deck " + deck.getMainDeck().size() + ", side deck " + deck.getSideDeck().size();
                if (deck.isValid()) toPrint += ", valid\n";
                else toPrint += ", invalid\n";
                activeDeck = deck;
            }
        }
        allDecks.remove(activeDeck);
        Comparator<Deck> deckComparator = Comparator.comparing(Deck::getDeckName);
        allDecks.sort(deckComparator);
        for (Deck deck : allDecks) {
            toPrint += deck.getDeckName() + ": main deck " + deck.getMainDeck().size() + ", side deck " + deck.getSideDeck().size();
            if (allDecks.get(allDecks.size() - 1).equals(deck)) {
                if (deck.isValid()) toPrint += ", valid";
                else toPrint += ", invalid";
            } else {
                if (deck.isValid()) toPrint += ", valid\n";
                else toPrint += ", invalid\n";
            }
        }
        DeckView.getInstance(this.user).printText(toPrint);
    }

    private void showDeck(String deckName, boolean isSide) {
        String toPrint = "Deck: " + deckName + "\n";
        if (isSide) toPrint += "Side deck:\nMonsters:\n";
        else toPrint += "Main deck:\nMonsters:\n";
        ArrayList<Card> monsterCards = new ArrayList<>();
        ArrayList<Card> spellAndTrapCards = new ArrayList<>();
        if (!isSide) {
            for (Card eachCard : this.user.getDeckByName(deckName).getMainDeck()) {
                if (eachCard instanceof MonsterCard) monsterCards.add(eachCard);
                else spellAndTrapCards.add(eachCard);
            }
        } else {
            for (Card eachCard : this.user.getDeckByName(deckName).getSideDeck()) {
                if (eachCard instanceof MonsterCard) monsterCards.add(eachCard);
                else spellAndTrapCards.add(eachCard);
            }
        }
        Comparator<Card> cardComparator = Comparator.comparing(Card::getNamePascalCase);
        monsterCards.sort(cardComparator);
        spellAndTrapCards.sort(cardComparator);
        for (Card eachCard : monsterCards) {
            toPrint += eachCard.getNamePascalCase() + ":" + eachCard.getDescription() + "\n";
        }
        toPrint += "Spell and Traps:\n";
        for (Card eachCard : spellAndTrapCards) {
            toPrint += eachCard.getNamePascalCase() + ":" + eachCard.getDescription() + "\n";
        }
        DeckView.getInstance(this.user).printText(toPrint);
    }

    private void showAllCards() {
        String toPrint = null;
        List<Card> allCards = user.getAllCards();
        Comparator<Card> cardComparator = Comparator.comparing(Card::getNamePascalCase);
        allCards.sort(cardComparator);
        for (Card card : allCards) {
            toPrint += card.getNamePascalCase() + ":" + card.getDescription() + "\n";
        }
        DeckView.getInstance(this.user).printText(toPrint);
    }

    private Matcher getCommandMatcher(String command, String regex) {
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(command);
    }

}
