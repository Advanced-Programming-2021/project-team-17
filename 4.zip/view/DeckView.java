package view;

import controller.DeckController;
import model.Deck;
import model.User;

public class DeckView {
    private static DeckView instance = null;
    private User user;

    public static DeckView getInstance(User user) {
        if(instance==null) instance = new DeckView(user);
        else instance.user = user;
        return instance;
    }

    private DeckView(User user){
        this.user = user;
    }
    private void getCommandForDeck(){

    }

    public void showMenu(){

    }

    public void exitMenu(){

    }

    public void printException(Exception output){

    }

    public void printText(String output){
        System.out.println(output);
    }
}
