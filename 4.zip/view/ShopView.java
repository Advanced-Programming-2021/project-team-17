package view;
import model.*;
public class ShopView {

    private User user;
    private void getCommandForShop(){

    }

    public void showMenu(){

    }

    public void exitMenu(){

    }

    public void printExeption(Exception output){

    }

    public void printText(String output){
        System.out.println(output);
    }
}
