package view;

import java.util.Scanner;

public class ScannerClassForView {
    static Scanner scanner = new Scanner(System.in);

    static Scanner getScanner() {
        return scanner;
    }
}
